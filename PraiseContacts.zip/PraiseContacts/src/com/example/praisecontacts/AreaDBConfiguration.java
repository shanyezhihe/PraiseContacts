package com.example.praisecontacts;

public class AreaDBConfiguration {
	public static final String DB_PATH = "area";
	public static final String DB_NAME = "area.db";
	public static final int DB_VERSION = 1;
	public static int oldVersion = -1;
	
}